# Donate 打赏作者

本项目的作者@nl8590687 (repo owner)现在其实还是一名学生...

如果您觉得本项目给您的学习和工作带来了一些帮助，可以考虑给作者一些打赏，用来给他在炎热的夏天买一瓶冰可乐，或者寒冷的冬天买一杯热奶茶，以鼓励其创作出更好的代码和项目。

二维码：

| 支付宝收款码   |微信收款码    |
| --------   | -----   |
| <img src="https://raw.githubusercontent.com/wiki/nl8590687/ASRT_SpeechRecognition/assets/Alipay_QRCODE.png" width = "300" height = "300" alt="支付宝收款二维码" />        | <img src="https://raw.githubusercontent.com/wiki/nl8590687/ASRT_SpeechRecognition/assets/Wechat_QRCODE.png" width = "300" height = "300" alt="微信收款二维码" />
 
